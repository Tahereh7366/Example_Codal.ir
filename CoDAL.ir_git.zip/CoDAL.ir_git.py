#!/usr/bin/env python
# coding: utf-8

# # 
# برای دسترسی به جدول هایی از سایت codal.ir شامل صورت های مالی میتوان از کتابخانه ایی از پایتون به نام Request , BeautifulSoup که در واقع نوعی خزش روی سایت کدال می باشد.

# # در این جا چندین نمونه برای خزش روی سایت آورده شده است:

# In[1]:


import urllib.request
import pandas as pd
from urllib.parse import unquote
from bs4 import BeautifulSoup
yurl='https://www.codal.ir/Reports/Decision.aspx?LetterSerial=T1hETjlDjOQQQaQQQfaL0Mb7uucg%3D%3D&rt=0&let=6&ct=0&ft=-1&sheetId=0'
req=urllib.request.urlopen(yurl)
print(req.status)
#get response
response = req.read()
html = response.decode("utf-8")
#make html readable
soup = BeautifulSoup(html, features="html")
table_body=soup.find_all("table")
print(table_body)


# با مشاهده کد 200 منظور این است که دسترسی آزاد است و ما میتوانیم دیتاها را مشاهده کنیم. البته کمی هم باید برای تمیز کردن این جداول زمان گذاشت

# In[6]:


#table_body
soup


# # روش دوم

# In[7]:


import requests

url = 'https://www.codal.ir/Reports/Decision.aspx?LetterSerial=WKtPU0bI3Esd0QyJNI%2bVwg%3d%3d&rt=1&let=6&ct=0&ft=-1'
headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36'}

response= requests.get(url.strip(), headers=headers, timeout=10)
response.content


# In[8]:


response.json


# # روش سوم

# In[9]:


from bs4 import BeautifulSoup

from selenium import webdriver
from selenium.webdriver.chrome.options import Options

option = Options()
option.add_argument('--headless')
url = 'https://www.codal.ir/Reports/Decision.aspx?LetterSerial=T1hETjlDjOQQQaQQQfaL0Mb7uucg%3D%3D&rt=0&let=6&ct=0&ft=-1&sheetId=0'
driver = webdriver.Chrome(options=option)
driver.get(url)
bs = BeautifulSoup(driver.page_source, 'html.parser')
print(bs.find('table'))
driver.quit()


# In[ ]:




