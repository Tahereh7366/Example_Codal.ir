#!/usr/bin/env python
# coding: utf-8

# # 1) Loading the Python packages.

# In[22]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt 


# In[4]:


url="C:/Users/Ateeq/Downloads/SIPA-O-14011210.csv"


# In[11]:


Call_Option_Saipa=pd.read_csv("C:/Users/Ateeq/Downloads/SIPA-O-14011210.csv", parse_dates=True, index_col="<DTYYYYMMDD>")[::-1]
Call_Option_Saipa


# In[12]:


Call_Option_Saipa.describe()


# In[16]:


Call_Option_Saipa["<CLOSE>"]["2022-10-22" :]


# # The maximum & minimum value of Close PRICE

# In[20]:


print("The maximum value is:",Call_Option_Saipa["<CLOSE>"].max())
print("The minimum value is:",Call_Option_Saipa["<CLOSE>"].min())
print("The day of maximum is:",Call_Option_Saipa["<CLOSE>"].argmax())
print("The day of minimum is:",Call_Option_Saipa["<CLOSE>"].argmin())
print("The number of days highest the mean:",Call_Option_Saipa["<CLOSE>"][Call_Option_Saipa["<CLOSE>"] > Call_Option_Saipa["<CLOSE>"].mean()].size)


# In[27]:


data=Call_Option_Saipa['<CLOSE>']
vol=Call_Option_Saipa['<VOL>']


x_min,y_min=data.loc[data==data.min()].index,data[data==data.min()]
x_max,y_max=data.loc[data==data.max()].index,data[data==data.max()]
y_mean=data.mean()
over_mean=np.array([1 for i in data if i>=y_mean]).sum()
below_mean=np.array([1 for i in data if i<y_mean]).sum()
print(over_mean,'days over mean.')
print(below_mean,'days below mean.')

fig, axs = plt.subplots(2, 1)
axs[0].plot(data)
axs[1].set_xlabel('Date')
axs[0].set_ylabel('close')
axs[1].set_ylabel('volume')
axs[0].axhline(y_mean,color='yellow')
axs[0].plot(x_min,y_min,'^',markersize=7,color='g',label='buy')
axs[0].plot(x_max,y_max,'v',markersize=7,color='r',label='sell')
x=[x_min,x_max]
y=[y_min,y_max]
axs[0].plot(x,y,'r')
axs[1].bar(vol.index,vol)


# #  Black, Scholes and Merton model.

# In[61]:


import numpy as np
from scipy.stats import norm
import matplotlib.pyplot as plt

N = norm.cdf

def BS_CALL(S, K, T, r, sigma):
    d1 = (np.log(S/K) + (r + sigma**2/2)*T) / (sigma*np.sqrt(T))
    d2 = d1 - sigma * np.sqrt(T)
    return S * N(d1) - K * np.exp(-r*T)* N(d2)

def BS_PUT(S, K, T, r, sigma):
    d1 = (np.log(S/K) + (r + sigma**2/2)*T) / (sigma*np.sqrt(T))
    d2 = d1 - sigma* np.sqrt(T)
    return K*np.exp(-r*T)*N(-d2) - S*N(-d1)


# # Effect on Option Value
# 

# In[62]:


K = 100
r = 0.1
T = 1
sigma = 0.3

S = np.arange(60,140,0.1)

calls = [BS_CALL(s, K, T, r, sigma) for s in S]


puts = [BS_PUT(s, K, T, r, sigma) for s in S]

plt.plot(S, calls, label='Call Value')
plt.plot(S, puts, label='Put Value')
plt.xlabel('$S_0$')
plt.ylabel(' Value')
plt.legend()




# # Effect on Black-Scholes Value
# 

# In[63]:


K = 100
r = 0.1
T = 1
Sigmas = np.arange(0.1, 1.5, 0.01)
S = 100

calls = [BS_CALL(S, K, T, r, sig) for sig in Sigmas]
puts = [BS_PUT(S, K, T, r, sig) for sig in Sigmas]
plt.plot(Sigma, calls, label='Call Value')
plt.plot(Sigma, puts, label='Put Value')
plt.xlabel('$\sigma$')
plt.ylabel(' Value')
plt.legend()


# # Effect of Time on Black-Scholes Price

# In[64]:


K = 100
r = 0.05
T = np.arange(0, 2, 0.01)
sigma = 0.3
S = 100

calls = [BS_CALL(S, K, t, r, sigma) for t in T]
puts = [BS_PUT(S, K, t, r, sigma) for t in T]
plt.plot(T, calls, label='Call Value')
plt.plot(T, puts, label='Put Value')
plt.xlabel('$T$ in years')
plt.ylabel(' Value')
plt.legend()


# In[66]:


def BSM(S0,K,T_t,rf,sigma):
    d1=(np.log(S0/k)+(rf+sigma**2/2)*T_t)/(sigma*np.sqrt(T_t))
    d2=d1-sigma*np.sqrt(T_t)
    C0=S0*norm.cdf(d1)-k*np.exp(-rf*T_t)*norm.cdf(d2)
    return C0


# In[78]:


C0=BSM(S0,K,T_t,rf,sigma)


# In[79]:


C0


# In[ ]:




